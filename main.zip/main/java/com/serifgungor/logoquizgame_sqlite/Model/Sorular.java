package com.serifgungor.logoquizgame_sqlite.Model;

public class Sorular {
    private int id;
    private int seviye_id;
    private String logo_url;
    private String kelime;
    private int puan;
    private int cozum_suresi;
    private int cozuldu_mu;

    public Sorular() {
    }

    public Sorular(int id, int seviye_id, String logo_url, String kelime, int puan, int cozum_suresi, int cozuldu_mu) {
        this.id = id;
        this.seviye_id = seviye_id;
        this.logo_url = logo_url;
        this.kelime = kelime;
        this.puan = puan;
        this.cozum_suresi = cozum_suresi;
        this.cozuldu_mu = cozuldu_mu;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getSeviye_id() {
        return seviye_id;
    }

    public void setSeviye_id(int seviye_id) {
        this.seviye_id = seviye_id;
    }

    public String getLogo_url() {
        return logo_url;
    }

    public void setLogo_url(String logo_url) {
        this.logo_url = logo_url;
    }

    public String getKelime() {
        return kelime;
    }

    public void setKelime(String kelime) {
        this.kelime = kelime;
    }

    public int getPuan() {
        return puan;
    }

    public void setPuan(int puan) {
        this.puan = puan;
    }

    public int getCozum_suresi() {
        return cozum_suresi;
    }

    public void setCozum_suresi(int cozum_suresi) {
        this.cozum_suresi = cozum_suresi;
    }

    public int getCozuldu_mu() {
        return cozuldu_mu;
    }

    public void setCozuldu_mu(int cozuldu_mu) {
        this.cozuldu_mu = cozuldu_mu;
    }
}
