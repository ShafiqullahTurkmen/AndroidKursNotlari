package com.serifgungor.logoquizgame_sqlite.Model;

public class Seviyeler {
    private int id;
    private int sure;
    private String baslik;
    private int baraj_puani;
    private String resim;

    public Seviyeler() {
    }

    public Seviyeler(int id, int sure, String baslik, int baraj_puani, String resim) {
        this.id = id;
        this.sure = sure;
        this.baslik = baslik;
        this.baraj_puani = baraj_puani;
        this.resim = resim;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getSure() {
        return sure;
    }

    public void setSure(int sure) {
        this.sure = sure;
    }

    public String getBaslik() {
        return baslik;
    }

    public void setBaslik(String baslik) {
        this.baslik = baslik;
    }

    public int getBaraj_puani() {
        return baraj_puani;
    }

    public void setBaraj_puani(int baraj_puani) {
        this.baraj_puani = baraj_puani;
    }

    public String getResim() {
        return resim;
    }

    public void setResim(String resim) {
        this.resim = resim;
    }
}
