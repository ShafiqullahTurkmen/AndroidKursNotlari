package com.serifgungor.logoquizgame_sqlite.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.serifgungor.logoquizgame_sqlite.Model.Seviyeler;
import com.serifgungor.logoquizgame_sqlite.R;

import java.util.ArrayList;

public class LevelAdapter extends BaseAdapter {
    ArrayList<Seviyeler> level;
    LayoutInflater layoutInflater;

    public LevelAdapter(){
    }

    public LevelAdapter(ArrayList<Seviyeler> level, Context context){
        this.level = level;
        this.layoutInflater = (LayoutInflater)
                context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }
    @Override
    public int getCount() {
        return level.size();
    }
    @Override
    public Object getItem(int position) {
        return level.get(position);
    }
    @Override
    public long getItemId(int position) {
        return level.get(position).getId();
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = layoutInflater.inflate(R.layout.custom_level_row,null);

        de.hdodenhof.circleimageview.CircleImageView civ = v.findViewById(R.id.level_image);
        TextView tvSeviyeCozumSayisi = v.findViewById(R.id.tvSeviyeCozumSayisi);
        ProgressBar progressSeviye = v.findViewById(R.id.progressSeviye);
        TextView tvPuan = v.findViewById(R.id.tvPuan);
        TextView tvSeviyeBaslik = v.findViewById(R.id.tvSeviyeBaslik);

        tvSeviyeBaslik.setText(level.get(position).getBaslik());

        int resId =
                v.getContext()
                        .getResources()
                        .getIdentifier(level.get(position).getResim(),"drawable",v.getContext().getPackageName());

        civ.setImageResource(resId);

        /*
        Identifier Kavramı

        Herhangi bir resources klasörü içerisinde dosya adını bildiğimiz bir nesnenin
        referansını int olarak almak istediğimizde, identifier tanımlamasına ihtiyaç duyarız

        şu ismi ara,şu klasör içerisinde ara,şu paket içerisinde ara
        getIdentifier("dosya_adi","drawable",getPackageName)
        bulunduğum proje içerisindeki drawable klasöründe dosya_adi dosyasına ait int
        referansı döner
         */


        return v;
    }
}
